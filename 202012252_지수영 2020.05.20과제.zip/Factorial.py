I = 1
Factorial = 1
while I <= 10:
    Factorial *= I
    I += 1
print(Factorial)
