print("상품의 가격을 입력하시오: ")
price = int(input(""))
if price > 100000:
    shipping_cost = 0
else:
    if price > 20000:
        shipping_cost = 3000
    else:
        shipping_cost = 5000
print("배송료 = ", shipping_cost)
