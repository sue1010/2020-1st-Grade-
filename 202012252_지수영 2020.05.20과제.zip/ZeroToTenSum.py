x = 1
total = 0
while x <= 10:
    total += x
    x += 1
print(total)
