button = int(input("몇 층으로 가시겠습니까?(1,2,3): "))
while button != 0:
    LED = ['LED1', 'LED2', 'LED3']
    if button == 1:
        print(LED[0])
        print("1층으로 갑니다")
        print("1분만 기다려 주세요")
        print("모든 LED를 끕니다")
        print("1층으로 갑니다")
        button = int(input("몇 층으로 가시겠습니까?(1,2,3): "))
    elif button == 2:
        print(LED[1])
        print("2층으로 갑니다")
        print("1분만 기다려 주세요")
        print("모든 LED를 끕니다")
        print("1층으로 갑니다")
        button = int(input("몇 층으로 가시겠습니까?(1,2,3): "))
    elif button == 3:
        print(LED[2])
        print("3층으로 갑니다")
        print("1분만 기다려 주세요")
        print("모든 LED를 끕니다")
        print("1층으로 갑니다")
        button = int(input("몇 층으로 가시겠습니까?(1,2,3): "))
    else:
        print("1층으로 갑니다")
        break
print("프로그램이 종료되었습니다.")
