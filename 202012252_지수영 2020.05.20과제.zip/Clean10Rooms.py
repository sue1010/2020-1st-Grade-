i = 0
while i != 10:
    print(i,"번째 방을 청소하는 중입니다")
    i += 1
    
