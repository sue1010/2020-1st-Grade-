I = 1
while I <= 100:
    if I % 3 == 0:
        print("박수")
    else:
        print(I)
    I += 1
