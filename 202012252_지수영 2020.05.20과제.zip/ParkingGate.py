numberOfCars = 0
while numberOfCars < 10:
    gate = input("입구 게이트에 차가 있는가?(yes,no): ")
    if gate == 'yes':
        if numberOfCars < 10:
            print("입구 게이트를 연다")
            numberOfCars += 1
            print("입구 게이트를 닫는다")
        else:
            print("자리가 없습니다")
            break
