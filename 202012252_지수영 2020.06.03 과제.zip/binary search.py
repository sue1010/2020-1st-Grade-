def binarySearch(alist, item):
    first = 0
    last = len(alist)-1
    found = False

    while first <= last and not found:
        midpoint = (first + last)//2
        if alist[midpoint] == item:
            found = True
        elif item < alist[midpoint]:
            last = midpoint - 1
        else:
            first = midpoint + 1
    return found

alist = [ 1, 3, 5, 6, 7, 9, 11, 20, 30, 56]
value = int(input("탐색하고자 하는 값은?"))
print(binarySearch(alist, value))
