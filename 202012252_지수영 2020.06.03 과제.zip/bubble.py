import turtle

data = [ 90, 10, 23, 17, 56, 39]

def drawBarChart(t,value):
    t.begin_fill()
    t.left(90)
    t.forward(value)
    t.right(90)
    t.forward(40)
    t.right(90)
    t.forward(value)
    t.left(90)
    t.end_fill()

def bubbleSort(alist):
    for p in range(len(alist)-1):
        for i in range(len(alist)-1):
            if alist[i] > alist[i+1]:
                temp = alist[i]
                alist[i] = alist[i+1]
                alist[i+1] = temp
        t.color()
        t.goto(0,0)
        t.speed(0)
    for d in alist:
        drawBarChart(t,d)
                
                
t = turtle.Turtle()
t.color("red")
t.fillcolor("blue")
t.pensize(3)
bubbleSort(data)
print(data)
