import random

def draw_board(board):
    print('------------')
    print(' '+board[1]+'|'+board[2]+'|'+board[3])
    print('------------')
    print(' '+board[4]+'|'+board[5]+'|'+board[6])
    print('------------')
    print(' '+board[7]+'|'+board[8]+'|'+board[9])
    print('------------')

def check_for_win(b,p):
    if ((b[1]==p and b[2]==p and b[3]==p) or
    (b[4]==p and b[5]==p and b[6]==p) or
    (b[7]==p and b[8]==p and b[9]==p) or
    (b[1]==p and b[4]==p and b[7]==p) or
    (b[2]==p and b[5]==p and b[8]==p) or
    (b[3]==p and b[6]==p and b[9]==p) or
    (b[3]==p and b[5]==p and b[7]==p) or
    (b[1]==p and b[5]==p and b[9]==p)) :
        return True
    else:
        return False

def is_free(board, loc):
    return board[loc] == ' '

def get_user_move(board):
    loc = int(input('1부터 9사이의 정수: '))
    return loc

def get_computer_move(board):

    for i in range(1, 10):
        if is_free(board, i):
            board[i] = 'O'
            if check_for_win(board, 'O'):
                board[i] = ' '
                return i
            board[i] = ' '

    for i in range(1, 10):
        if is_free(board, i):
            board[i] = 'X'
            if check_for_win(board, 'X'):
                board[i] = ' '
                return i
            board[i] = ' '

    for i in [1,3,7,9]:
        if is_free(board, i):
            return i

    if is_free(board, 5):
        return 5

    for i in [2,4,6,8]:
        if is_free(board, i):
            return i

def check_for_tie(board):
    for i in range(1,10):
        if is_free(board, i):
            return False
    return True

print('Tic Tac Toe 게임에 오신 것을 환영합니다.')
board = [' ',' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ']
playing = True
turn = 'X'

while playing:
    draw_board(board)
    if turn == 'X':
        loc = get_user_move(board)
        board[loc] = 'X'
    else:
        loc = get_computer_move(board)
        board[loc] = 'O'

    if check_for_win(board, turn):
        draw_board(board)
        print(turn + '승리')
        playing = False
    else:
        if check_for_tie(board):
            draw_board(board)
            print('무승부')
            playing = False
        else:
            if turn == 'X':
                turn = 'O'
            else:
                turn = 'X'
