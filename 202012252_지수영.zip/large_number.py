print("정수를 입력하시오: ")
x = int(input("x = "))
y = int(input("y = "))
if x > y:
    print(x)
else:
    print(y)
    
