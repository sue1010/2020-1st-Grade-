print("상품의 가격을 입력하시오")
price = int(input("상품의 가격 = "))
vat = price * 0.1
print(vat)
