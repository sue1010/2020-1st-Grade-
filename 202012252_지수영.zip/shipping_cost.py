print("상품을 가격을 입력하시오: ")
price = int(input("가격 = "))
if price > 20000:
    shipping_cost = 0
    print("배송료는 ", shipping_cost, "원 입니다")
else:
    shipping_cost = 3000
    print("배송료는 ", shipping_cost, "원 입니다")
