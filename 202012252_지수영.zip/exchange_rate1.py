won = 100000
usd = won / 1130
print(usd)
