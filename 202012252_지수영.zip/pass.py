print("성적을 입력하시오: ")
grade = int(input("성적 = "))
if grade >= 60:
    print("합격")
    
