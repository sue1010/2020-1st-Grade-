print("나이를 입력하시오")
age = int(input("나이 = "))
age = age + 1
print("내년이면", age, "가 되시는 군요")
