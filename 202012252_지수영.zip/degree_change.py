#1
fahrenheit = 100
celsius = fahrenheit-32
celsius = celsius * 5
celsius = celsius/9
print(celsius)

#2
fahrenheit = 100
celsius = 5*(fahrenheit-32)/9
print(celsius)
