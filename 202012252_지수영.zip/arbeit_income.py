hours_worked = 10
pay_rate = 6000
monthly_pay = hours_worked * pay_rate
print(monthly_pay)
