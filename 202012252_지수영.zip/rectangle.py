print("사각형의 가로와 세로를 입력하시오")
length = int(input('세로 = '))
width = int(input('가로 = '))
area = length * width
print(area)
