print("3개의 값을 입력하시오: ")
x = int(input('x = '))
y = int(input('y = '))
z = int(input('z = '))

x = x + 1
y = y + 1
z = z + 1

print("변경된 값: ",x,y,z)
