print("정수를 입력하시오:")
x = int(input("x = "))
if (x % 2) != 0:
    print("홀수")
else:
    print("짝수")
