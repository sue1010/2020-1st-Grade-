print("정수 2개를 입력하시오")
x = int(input("x = "))
y = int(input("y = "))
sum = x + y
print(sum)
