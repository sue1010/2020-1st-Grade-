print("현재의 환율을 입력하시오: ")
exchange_rate = int(input(''))
won = 100000
usd = won / exchange_rate
print(usd)
