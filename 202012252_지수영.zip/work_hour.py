print("근무 시간을 입력하시오: ")
work_hour = int(input("근무 시간 = "))
if work_hour > 72:
    print("초과근무")
else:
    print("정상근무")
